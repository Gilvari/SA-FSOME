import torch
import torch.nn as nn
from torchvision import models
import torch.nn.functional as F



class RESNET_pre(nn.Module):
  def __init__(self):
      super(RESNET_pre, self).__init__()

      self.features = models.resnet18(pretrained=True)


  def forward(self, x):
      x = torch.unsqueeze(x, dim =0)
      x= self.features(x)
      x=nn.Sigmoid()(x)

      return x #output

# class RESNET_pre_50(nn.Module):
#     def __init__(self, num_classes=1, dropout_rate=0.3):
#         super(RESNET_pre_50, self).__init__()
#         self.model = models.resnet101(weights=models.ResNet101_Weights.DEFAULT)
#
#         # Modify the fully connected layer
#         in_features = self.model.fc.in_features
#         self.model.fc = nn.Sequential(
#             nn.Dropout(dropout_rate),
#             nn.Linear(in_features, num_classes)
#         )
#
#     def forward(self, x):
#         if x.dim() == 3:  # Ensure input is 4D (B, C, H, W)
#             x = x.unsqueeze(0)
#         x = self.model(x)
#         x = torch.sigmoid(x)
#         return x


# ResNet-34
class RESNET_pre_101(nn.Module):
    def __init__(self):
        super(RESNET_pre_101, self).__init__()
        self.features = models.resnet34(pretrained=True)

    def forward(self, x):
        if x.dim() == 3:
            x = x.unsqueeze(0)
        x = self.features(x)
        x = torch.sigmoid(x)
        return x

# ResNet-50
class RESNET_pre_50(nn.Module):
    def __init__(self):
        super(RESNET_pre_50, self).__init__()
        self.features = models.resnet50(pretrained=True)

    def forward(self, x):
        if x.dim() == 3:
            x = x.unsqueeze(0)
        x = self.features(x)
        x = torch.sigmoid(x)
        return x


# ResNet101
# class RESNET_pre_101(nn.Module):
#     def __init__(self):
#         super(RESNET_pre_101, self).__init__()
#         self.features = models.resnet101(weights=models.ResNet101_Weights.DEFAULT)
#
#     def forward(self, x):
#         if x.dim() == 3:  # Ensure input is 4D
#             x = x.unsqueeze(0)
#         x = self.features(x)
#         x = torch.sigmoid(x)
#         return x



# class RESNET_pre(nn.Module):
#     def __init__(self, dropout_rate=0.5):
#         super(RESNET_pre, self).__init__()
#
#         # Load pre-trained ResNet18 model
#         self.features = models.resnet18(pretrained=True)
#
#         # Modify the fully connected layer to include dropout
#         num_ftrs = self.features.fc.in_features
#         self.features.fc = nn.Sequential(
#             nn.Dropout(p=dropout_rate),  # Dropout layer before FC
#             nn.Linear(num_ftrs, 1),  # Output layer with 1 neuron (for binary classification)
#             nn.Sigmoid()  # Sigmoid activation
#         )
#
#     def forward(self, x):
#         x = torch.unsqueeze(x, dim=0)  # Ensure correct input shape
#         x = self.features(x)
#         return x  # Output
#



class CIFAR_VGG3(nn.Module):
  def __init__(self,vector_size, biases):
      super(CIFAR_VGG3, self).__init__()

      self.act = nn.LeakyReLU()
      self.block1=models.vgg16().features[0]
      self.block1.bias.requires_grad = False
      self.bn1 = nn.BatchNorm2d(64, eps=1e-04, affine=False)
      self.bn2 = nn.BatchNorm2d(64, eps=1e-04, affine=False)
      self.bn3 = nn.BatchNorm2d(128, eps=1e-04, affine=False)
      self.bn4 = nn.BatchNorm2d(128, eps=1e-04, affine=False)
      self.bn5 = nn.BatchNorm2d(256, eps=1e-04, affine=False)

      self.block2=models.vgg16().features[2]
      self.block3=models.vgg16().features[4:6]
      self.block4=models.vgg16().features[7]
      self.block5=models.vgg16().features[9:11]
      self.block6=models.vgg16().features[12]
      self.block7=models.vgg16().features[14]
      self.block8=models.vgg16().features[16]
      self.classifier = nn.Linear(4096, vector_size,bias=False)


      if biases == 0:
          self.block1.bias.requires_grad = False
          self.block2.bias.requires_grad = False
          self.block3[1].bias.requires_grad = False
          self.block4.bias.requires_grad = False
          self.block5[1].bias.requires_grad = False
          self.block6.bias.requires_grad = False
          self.block7.bias.requires_grad = False


  def forward(self, x):
      x = torch.unsqueeze(x, dim =0)
      x= self.block1(x)
      x=self.bn1(x)
      x=self.act(x)
      x= self.block2(x)
      x=self.bn2(x)
      x=self.act(x)
      x= self.block3(x)
      x=self.bn3(x)
      x=self.act(x)
      x= self.block4(x)
      x=self.bn4(x)
      x=self.act(x)
      x= self.block5(x)
      x=self.bn5(x)
      x=self.act(x)
      x= self.block6(x)
      x=self.act(x)
      x= self.block7(x)
      x=self.act(x)
      x= self.block8(x)
      x=self.act(x)
      x = x.view(x.size(0), -1)
      x = self.classifier(x)
      x=nn.Sigmoid()(x)
      return x #output



class CIFAR_VGG3_pre(nn.Module):
  def __init__(self,vector_size, biases):
      super(CIFAR_VGG3_pre, self).__init__()

      self.act = nn.LeakyReLU()
      self.block1=models.vgg16(pretrained = True).features[0]
      self.block1.bias.requires_grad = False
      self.bn1 = nn.BatchNorm2d(64, eps=1e-04, affine=False)
      self.bn2 = nn.BatchNorm2d(64, eps=1e-04, affine=False)
      self.bn3 = nn.BatchNorm2d(128, eps=1e-04, affine=False)
      self.bn4 = nn.BatchNorm2d(128, eps=1e-04, affine=False)
      self.bn5 = nn.BatchNorm2d(256, eps=1e-04, affine=False)
      self.bn6 = nn.BatchNorm2d(256, eps=1e-04, affine=False)
      self.bn7 = nn.BatchNorm2d(256, eps=1e-04, affine=False)
      self.bn8 = nn.BatchNorm2d(256, eps=1e-04, affine=False)
      self.block2=models.vgg16(pretrained = True).features[2]
      self.block3=models.vgg16(pretrained = True).features[4:6]
      self.block4=models.vgg16(pretrained = True).features[7]
      self.block5=models.vgg16(pretrained = True).features[9:11]
      self.block6=models.vgg16(pretrained = True).features[12]
      self.block7=models.vgg16(pretrained = True).features[14]
      self.block8=models.vgg16(pretrained = True).features[16]
      self.classifier = nn.Linear(4096, vector_size,bias=False)

      if biases == 0:
          self.block1.bias.requires_grad = False
          self.block2.bias.requires_grad = False
          self.block3[1].bias.requires_grad = False
          self.block4.bias.requires_grad = False
          self.block5[1].bias.requires_grad = False
          self.block6.bias.requires_grad = False
          self.block7.bias.requires_grad = False



  def forward(self, x):
      x = torch.unsqueeze(x, dim =0)
      x= self.block1(x)
      x=self.bn1(x)
      x=self.act(x)
      x= self.block2(x)
      x=self.act(x)
      x= self.block3(x)
      x=self.act(x)
      x= self.block4(x)
      x=self.act(x)
      x= self.block5(x)
      x=self.act(x)
      x= self.block6(x)
      x=self.act(x)
      x= self.block7(x)
      x=self.act(x)
      x= self.block8(x)
      x=self.act(x)


      x = x.view(x.size(0), -1)
      x = self.classifier(x)
      x=nn.Sigmoid()(x)

      return x #output






class FASHION_VGG3_pre(nn.Module):
  def __init__(self,vector_size, biases):
      super(FASHION_VGG3_pre, self).__init__()

      self.act = nn.LeakyReLU()
      self.block1=models.vgg16(pretrained = True).features[0]
      self.block1.bias.requires_grad = False
      self.bn1 = nn.BatchNorm2d(64, eps=1e-04, affine=False)
      self.bn2 = nn.BatchNorm2d(64, eps=1e-04, affine=False)
      self.bn3 = nn.BatchNorm2d(128, eps=1e-04, affine=False)
      self.bn4 = nn.BatchNorm2d(128, eps=1e-04, affine=False)
      self.bn5 = nn.BatchNorm2d(256, eps=1e-04, affine=False)
      self.bn6 = nn.BatchNorm2d(256, eps=1e-04, affine=False)
      self.bn7 = nn.BatchNorm2d(256, eps=1e-04, affine=False)
      self.bn8 = nn.BatchNorm2d(256, eps=1e-04, affine=False)
      self.block2=models.vgg16(pretrained = True).features[2]
      self.block3=models.vgg16(pretrained = True).features[4:6]
      self.block4=models.vgg16(pretrained = True).features[7]
      self.block5=models.vgg16(pretrained = True).features[9:11]
      self.block6=models.vgg16(pretrained = True).features[12]
      self.block7=models.vgg16(pretrained = True).features[14]
      self.block8=models.vgg16(pretrained = True).features[16]
      self.classifier = nn.Linear(2304, vector_size,bias=False)

      if biases == 0:
          self.block1.bias.requires_grad = False
          self.block2.bias.requires_grad = False
          self.block3[1].bias.requires_grad = False
          self.block4.bias.requires_grad = False
          self.block5[1].bias.requires_grad = False
          self.block6.bias.requires_grad = False
          self.block7.bias.requires_grad = False



  def forward(self, x):
      x = torch.unsqueeze(x, dim =0)
      x= self.block1(x)
      x=self.bn1(x)
      x=self.act(x)
      x= self.block2(x)
      x=self.act(x)
      x= self.block3(x)
      x=self.act(x)
      x= self.block4(x)
      x=self.act(x)
      x= self.block5(x)
      x=self.act(x)
      x= self.block6(x)
      x=self.act(x)
      x= self.block7(x)
      x=self.act(x)
      x= self.block8(x)
      x=self.act(x)


      x = x.view(x.size(0), -1)
      x = self.classifier(x)
      x=nn.Sigmoid()(x)

      return x #output




class MNIST_VGG3(nn.Module):
  def __init__(self,vector_size):
      super(MNIST_VGG3, self).__init__()

      self.act = nn.LeakyReLU()
      self.block1=models.vgg16().features[0]
      self.bn1 = nn.BatchNorm2d(64, eps=1e-04, affine=False)

      self.block2=models.vgg16().features[2]
      self.block3=models.vgg16().features[4:6]
      self.block4=models.vgg16().features[7]
      self.block5=models.vgg16().features[9:11]
      self.block6=models.vgg16().features[12]
      self.block7=models.vgg16().features[14]
      self.block8=models.vgg16().features[16]
      self.classifier = nn.Linear(2304, vector_size,bias=False)

  def forward(self, x):
      x = torch.unsqueeze(x, dim =0)
      x= self.block1(x)
      x=self.bn1(x)
      x=self.act(x)
      x= self.block2(x)
      x=self.act(x)
      x= self.block3(x)
      x=self.act(x)
      x= self.block4(x)
      x=self.act(x)
      x= self.block5(x)
      x=self.act(x)
      x= self.block6(x)
      x=self.act(x)
      x= self.block7(x)
      x=self.act(x)
      x= self.block8(x)
      x=self.act(x)


      x = x.view(x.size(0), -1)
      x = self.classifier(x)
      x=nn.Sigmoid()(x)

      return x #output





class MNIST_VGG3_pre(nn.Module):
  def __init__(self,vector_size, biases):
      super(MNIST_VGG3_pre, self).__init__()

      self.act = nn.LeakyReLU()
      self.block1=models.vgg16(pretrained = True).features[0]
      self.bn1 = nn.BatchNorm2d(64, eps=1e-04, affine=False)

      self.block2=models.vgg16(pretrained = True).features[2]
      self.block3=models.vgg16(pretrained = True).features[4:6]
      self.block4=models.vgg16(pretrained = True).features[7]
      self.block5=models.vgg16(pretrained = True).features[9:11]
      self.block6=models.vgg16(pretrained = True).features[12]
      self.block7=models.vgg16(pretrained = True).features[14]
      self.block8=models.vgg16(pretrained = True).features[16]
      self.classifier = nn.Linear(2304, vector_size,bias=False)


      if biases == 0:
          self.block1.bias.requires_grad = False
          self.block2.bias.requires_grad = False
          self.block3[1].bias.requires_grad = False
          self.block4.bias.requires_grad = False
          self.block5[1].bias.requires_grad = False
          self.block6.bias.requires_grad = False
          self.block7.bias.requires_grad = False



  def forward(self, x):
      x = torch.unsqueeze(x, dim =0)
      x= self.block1(x)
      x=self.bn1(x)
      x=self.act(x)
      x= self.block2(x)
      x=self.act(x)
      x= self.block3(x)
      x=self.act(x)
      x= self.block4(x)
      x=self.act(x)
      x= self.block5(x)
      x=self.act(x)
      x= self.block6(x)
      x=self.act(x)
      x= self.block7(x)
      x=self.act(x)
      x= self.block8(x)
      x=self.act(x)
      x = x.view(x.size(0), -1)
      x = self.classifier(x)
      x=nn.Sigmoid()(x)

      return x #output
