import torch.nn.functional as F
import torch
from model import *
import os
import numpy as np
import pandas as pd
import argparse
from sklearn.metrics import roc_curve
from sklearn import metrics
from datasets.main import load_dataset
import random
from sklearn.metrics import f1_score
from sklearn.metrics import matthews_corrcoef
import time
from sklearn.metrics import cohen_kappa_score
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.manifold import TSNE
import pickle
import matplotlib.pyplot as plt
import re




# def normalize_tsne(tsne_results, range_min=-10, range_max=10):
#     """Normalize t-SNE results to a fixed range [-10, 10]"""
#     scaler = MinMaxScaler(feature_range=(range_min, range_max))
#     return scaler.fit_transform(tsne_results)

# TSNE_ANCHOR_PATH = os.path.join("outputs_Visualization", "anchor_tsne.pkl")
#
# # File to store the fixed anchor t-SNE position
TSNE_ANCHOR_PATH = os.path.join("outputs_Visualization", "anchor_tsne.pkl")

def normalize_tsne(tsne_results, range_min=-10, range_max=10):
    """Normalize t-SNE results to a fixed range [-10, 10]"""
    scaler = MinMaxScaler(feature_range=(range_min, range_max))
    return scaler.fit_transform(tsne_results)



def visualize6(anchor_embedding, reference_embeddings, test_embeddings, test_labels, epoch,ref_image_names, test_image_names):
    """
    Visualize embeddings using t-SNE.

    - Reference embeddings: Blue
    - Anchor: Yellow (Fixed position)
    - Test embeddings: Green (normal) or Red (anomalous) based on label
    """
    output_dir = "outputs_Visualization"
    os.makedirs(output_dir, exist_ok=True)

    # Ensure anchor is (1, 1000)
    anchor_embedding = anchor_embedding.reshape(1, -1)

    # Convert reference embeddings to (N, 1000)
    ref_embeddings = np.stack([
        tensor.detach().cpu().numpy().reshape(-1) for tensor in reference_embeddings.values()
    ])

    # Convert test embeddings to (M, 1000)
    test_embeds = np.stack([
        tensor.detach().cpu().numpy().reshape(-1) if isinstance(tensor, torch.Tensor) else tensor.reshape(-1)
        for tensor in test_embeddings
    ])

    # print(f"🔍 Anchor shape: {anchor_embedding.shape}")
    # print(f"🔍 Reference shape: {ref_embeddings.shape}")
    # print(f"🔍 Test shape: {test_embeds.shape}")
    # print(f"🔍 Test labels: {test_labels}")  # Ensure labels are correctly loaded

    num_refs = len(ref_embeddings)

    # Load or compute t-SNE
    if epoch == 0 or not os.path.exists(TSNE_ANCHOR_PATH):
        # print("🔹 Computing t-SNE for the first time (Epoch 0)")
        all_embeddings = np.vstack([ref_embeddings, anchor_embedding, test_embeds])

        # Run t-SNE for the first epoch
        tsne = TSNE(n_components=2, random_state=42, perplexity=30, learning_rate=200, init="pca")
        tsne_results = tsne.fit_transform(all_embeddings)
        tsne_results = normalize_tsne(tsne_results)

        # Store fixed anchor position
        anchor_tsne = tsne_results[num_refs]  # Fixed anchor position
        with open(TSNE_ANCHOR_PATH, "wb") as f:
            pickle.dump(anchor_tsne, f)
    else:
        # print("🔹 Loading fixed anchor t-SNE position")
        with open(TSNE_ANCHOR_PATH, "rb") as f:
            anchor_tsne = pickle.load(f)

        # Compute t-SNE for reference + test embeddings only
        tsne = TSNE(n_components=2, random_state=42, perplexity=30, learning_rate=200, init="pca")
        tsne_results = tsne.fit_transform(np.vstack([ref_embeddings, test_embeds]))
        tsne_results = normalize_tsne(tsne_results)

        # Insert fixed anchor at the same index
        tsne_results = np.insert(tsne_results, num_refs, anchor_tsne, axis=0)

    # Extract transformed coordinates
    ref_tsne = tsne_results[:num_refs]  # Reference embeddings
    anchor_tsne = tsne_results[num_refs]  # Fixed anchor position
    test_tsne = tsne_results[num_refs + 1:]  # Test embeddings

    ref_image_names = [re.sub(r"[^\w\d]+", "", name.replace('.png', '')) for name in ref_image_names]
    test_image_names = [re.sub(r"[^\w\d]+", "", name.replace('.png', '')) for name in test_image_names]

    # --- Plotting ---
    plt.figure(figsize=(12, 8))

    # Reference Embeddings
    plt.scatter(ref_tsne[:, 0], ref_tsne[:, 1], c='blue', marker='s', alpha=0.7, label='Reference Embeddings')
    for i, (x, y) in enumerate(ref_tsne):
        plt.text(x + 0.2, y + 0.2, ref_image_names[i], fontsize=6, color='blue')
    # Anchor (Fixed Position)
    plt.scatter(anchor_tsne[0], anchor_tsne[1], c='yellow', marker='*', edgecolors='black', s=220, label='Anchor')

    # Test Embeddings - Color based on labels
    for i, (x, y) in enumerate(test_tsne):
        if test_labels[i] == 0:
            plt.scatter(x, y, c='green', edgecolors='black', s=50, marker='o')  # Green circle
            plt.text(x + 0.2, y + 0.2, test_image_names[i], fontsize=6, color='green')
        else:
            plt.scatter(x, y, c='red', edgecolors='black', s=50, marker='^')  # Red triangle
            plt.text(x + 0.2, y + 0.2, test_image_names[i], fontsize=6, color='red')




    # Legend for test embeddings
    plt.scatter([], [], c='green', label='Test Normal (Label=0)')
    plt.scatter([], [], c='red', marker='^', label='Test Anomalous (Label=1)')

    # Plot Styling
    plt.xlabel("t-SNE Dim 1")
    plt.ylabel("t-SNE Dim 2")
    plt.title(f"t-SNE Visualization of Feature Embeddings (Epoch {epoch})")
    plt.legend(loc='upper right')
    plt.grid(True)

    # Save plot
    tsne_plot_path = os.path.join(output_dir, f"tsne_visualization_epoch_{epoch}.png")
    plt.savefig(tsne_plot_path)
    plt.close()
    # print(f"✅ Saved t-SNE visualization for epoch {epoch} to {tsne_plot_path}")# def visualize6(anchor_embedding, reference_embeddings, test_embeddings, epoch):




evaluation_results = []
def deactivate_batchnorm(m):
    '''
        Deactivate batch normalisation layers
    '''
    if isinstance(m, nn.BatchNorm2d):
        m.reset_parameters()
        m.eval()
        with torch.no_grad():
            m.weight.fill_(1.0)
            m.bias.zero_()


class ContrastiveLoss(torch.nn.Module):
    def __init__(self, alpha, anchor, device, v=0.0,margin=0.8):
        super(ContrastiveLoss, self).__init__()

        self.margin = margin
        self.v = v
        self.alpha = alpha
        self.anchor = anchor
        self.device = device

    def forward(self, output1, vectors, label, output1_abnormal):
        '''
        Args:
            output1 - feature embedding/representation of current training instance
            vectors - list of feature embeddings/representations of training instances to contrast with output1
            label - value of zero if output1 and all vectors are normal, one if vectors are anomalies
        '''

        euclidean_distance = torch.FloatTensor([0]).to(self.device)

        #get the euclidean distance between output1 and all other vectors
        for i in vectors:
          euclidean_distance += (F.pairwise_distance(output1, i)/ torch.sqrt(torch.Tensor([output1.size()[1]])).to(self.device))

        # self.alpha = min(2.0, self.alpha * 1.05)
        euclidean_distance += self.alpha*((F.pairwise_distance(output1, self.anchor)) /torch.sqrt(torch.Tensor([output1.size()[1]])).to(self.device) )
        # self.margin = max(0.8, min(1.2, self.margin * 1.02))

        #calculate the margin
        marg = (len(vectors) + self.alpha) * self.margin
        #if v > 0.0, implement soft-boundary
        if self.v > 0.0:
            euclidean_distance = (1/self.v) * euclidean_distance
        #calculate the loss

        loss_contrastive = ((1-label) * torch.pow(euclidean_distance, 2)*0.5 ) + ( (label) * torch.pow(torch.max(torch.Tensor([ torch.tensor(0), marg - euclidean_distance])), 2)*0.5)

        return loss_contrastive


def evaluate(anchor, seed, base_ind, ref_dataset, val_dataset, model, dataset_name, normal_class, model_name, indexes, data_path, criterion, alpha, num_ref_eval, device,epoch=0):

    model.eval()


    #create loader for test dataset
    loader = torch.utils.data.DataLoader(val_dataset, batch_size=1, shuffle=True, num_workers=1, drop_last=False)
    outs={} #a dictionary where the key is the reference image and the values is a list of the distances between the reference image and all images in the test set
    ref_images={} #dictionary for feature vectors of reference set
    ind = list(range(0, num_ref_eval))
    np.random.shuffle(ind)
    #loop through the reference images and 1) get the reference image from the dataloader, 2) get the feature vector for the reference image and 3) initialise the values of the 'out' dictionary as a list.
    anchor_embedding = anchor.cpu().numpy().squeeze()
    ref_image_names = []
    for i in ind:
      img1, _, _, _,name = ref_dataset.__getitem__(i)
      if (i == base_ind):
        ref_images['images{}'.format(i)] = anchor
        anchor_embedding = anchor.cpu().numpy().squeeze()
      else:
        ref_images['images{}'.format(i)] = model.forward( img1.to(device).float())
      outs['outputs{}'.format(i)] =[]
      ref_image_names.append(name)




    means = []
    minimum_dists=[]
    lst=[]
    labels=[]
    loss_sum =0
    inf_times=[]
    total_times= []
    #loop through images in the dataloader
    all_outs = []
    test_image_names = []
    with torch.no_grad():
        for i, data in enumerate(loader):

            image = data[0][0]
            label = data[2].item()
            # name = data[4]
            name = data[4][0] if isinstance(data[4], (tuple, list)) else data[4]

            labels.append(label)
            total =0
            mini=torch.Tensor([1e50])
            t1 = time.time()
            out = model.forward(image.to(device).float()) #get feature vector (representation) for test image
            test_image_names.append(name)
            # print('out shape',out.shape)
            inf_times.append(time.time() - t1)
            all_outs.append(out.cpu().numpy())
            # print('all_outs shape', out.all_outs)
            #calculate the distance from the test image to each of the datapoints in the reference set
            for j in range(0, num_ref_eval):
                euclidean_distance = (F.pairwise_distance(out, ref_images['images{}'.format(j)]) / torch.sqrt(torch.Tensor([out.size()[1]])).to(device) ) + (alpha*(F.pairwise_distance(out, anchor) /torch.sqrt(torch.Tensor([out.size()[1]])).to(device) ))

                outs['outputs{}'.format(j)].append(euclidean_distance.item())
                total += euclidean_distance.item()
                if euclidean_distance.detach().item() < mini:
                  mini = euclidean_distance.item()

                loss_sum += criterion(out,[ref_images['images{}'.format(j)]], label).item()

            minimum_dists.append(mini)
            means.append(total/len(indexes))
            total_times.append(time.time()-t1)

            del image
            del out
            del euclidean_distance
            del total
            torch.cuda.empty_cache()


    #create dataframe of distances to each feature vector in the reference set for each test feature vector
    cols = ['label','minimum_dists', 'means']
    df = pd.concat([pd.DataFrame(labels, columns = ['label']), pd.DataFrame(minimum_dists, columns = ['minimum_dists']),  pd.DataFrame(means, columns = ['means'])], axis =1)
    for i in range(0, num_ref_eval):
        df= pd.concat([df, pd.DataFrame(outs['outputs{}'.format(i)])], axis =1)
        cols.append('ref{}'.format(i))
    df.columns=cols
    df = df.sort_values(by='minimum_dists', ascending = False).reset_index(drop=True)


    #calculate metrics
    fpr, tpr, thresholds = roc_curve(np.array(df['label']),np.array(df['minimum_dists']))
    auc_min = metrics.auc(fpr, tpr)
    outputs = np.array(df['minimum_dists'])
    thres = np.percentile(outputs, 15)
    outputs[outputs >= thres] =1
    outputs[outputs < thres] =0
    f1 = f1_score(np.array(df['label']),outputs)
    mcc = matthews_corrcoef(np.array(df['label']), outputs)


    # print('anchor_embedding.shape:',anchor_embedding.shape,'ref_images.shape:',ref_images.shape, 'all_outs.shape',all_outs.shape)
    visualize6(anchor_embedding, ref_images, all_outs, labels, epoch,ref_image_names,test_image_names)

    fp = len(df.loc[(outputs == 1 ) & (df['label'] == 0)])
    tn = len(df.loc[(outputs== 0) & (df['label'] == 0)])
    fn = len(df.loc[(outputs == 0) & (df['label'] == 1)])
    tp = len(df.loc[(outputs == 1) & (df['label'] == 1)])

    spec = tn / (fp + tn)
    recall = tp / (tp+fn)
    acc = (recall + spec) / 2
    # print('AUC: {}'.format(auc_min))
    # print('F1: {}'.format(f1))
    # print('Balanced accuracy: {}'.format(acc))
    # print(f'MCC: {mcc}')
    kappa = cohen_kappa_score(np.array(df['label']), outputs)
    # print(f'Cohen\'s Kappa: {kappa}')


    print('AUC {}'.format(auc_min))
    print('F1 {}'.format(f1))
    print('Balanced_accuracy {}'.format(acc))
    print(f'MCC: {mcc}')
    print(f'Cohen_Kappa: {kappa}')




    fpr, tpr, thresholds = roc_curve(np.array(df['label']),np.array(df['means']))
    auc = metrics.auc(fpr, tpr)





    #create dataframe of feature vectors for each image in the reference set
    feat_vecs = pd.DataFrame(ref_images['images0'].detach().cpu().numpy())
    for j in range(1, num_ref_eval):
        feat_vecs = pd.concat([feat_vecs, pd.DataFrame(ref_images['images{}'.format(j)].detach().cpu().numpy())], axis =0)

    avg_loss = (loss_sum / num_ref_eval )/ val_dataset.__len__()

    return auc, avg_loss, auc_min, f1,acc, df, feat_vecs, inf_times, total_times



def init_feat_vec(model,base_ind, train_dataset, device ):
        '''
        Initialise the anchor
        Args:
            model object
            base_ind - index of training data to convert to the anchor
            train_dataset - train dataset object
            device
        '''

        model.eval()
        anchor,_,_,_,_ = train_dataset.__getitem__(base_ind)
        with torch.no_grad():
          anchor = model(anchor.to(device).float())

        return anchor



def create_reference(contamination, dataset_name, normal_class, task, data_path, download_data, N, seed):
    '''
    Get indexes for reference set
    Include anomalies in the reference set if contamination > 0
    Args:
        contamination - level of contamination of anomlies in reference set
        dataset name
        normal class
        task - train/test/validate
        data_path - path to data
        download data
        N - number in reference set
        seed
    '''
    indexes = []
    train_dataset = load_dataset(dataset_name, indexes, normal_class,task, data_path, download_data) #get all training data
    ind = np.where(np.array(train_dataset.targets)==normal_class)[0] #get indexes in the training set that are equal to the normal class
    random.seed(seed)
    samp = random.sample(range(0, len(ind)), N) #randomly sample N normal data points
    final_indexes = ind[samp]
    if contamination != 0:
      numb = np.ceil(N*contamination)
      if numb == 0.0:
        numb=1.0

      con = np.where(np.array(train_dataset.targets)!=normal_class)[0] #get indexes of non-normal class
      samp = random.sample(range(0, len(con)), int(numb))
      samp2 = random.sample(range(0, len(final_indexes)), len(final_indexes) - int(numb))
      final_indexes = np.array(list(final_indexes[samp2]) + list(con[samp]))
    return final_indexes



def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('-m', '--model_name', type=str, required=True)
    parser.add_argument('--model_path', type=str, required=True)
    parser.add_argument('--model_type', choices = ['CIFAR_VGG3','CIFAR_VGG4','MNIST_VGG3', 'RESNET','RESNET50','RESNET_pre_101'], required=True)
    parser.add_argument('--dataset', type=str, required=True)
    parser.add_argument('--normal_class', type=int, default = 0)
    parser.add_argument('-N', '--num_ref', type=int, default = 30)
    parser.add_argument('--num_ref_eval', type=int, default = None)
    parser.add_argument('--num_ref_dist', type=int, default = None)
    parser.add_argument('--vector_size', type=int, default=1024)
    parser.add_argument('--seed', type=int, default = 100)
    parser.add_argument('--weight_init_seed', type=int, default = 100)
    parser.add_argument('--alpha', type=float, default = 0)
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--data_path',  required=True)
    parser.add_argument('--download_data',  default=True)
    parser.add_argument('--contamination',  type=float, default=0)
    parser.add_argument('--v',  type=float, default=0.0)
    parser.add_argument('--task',  default='train', choices = ['test', 'train'])
    parser.add_argument('--biases', type=int, default=1)
    parser.add_argument('--pretrain', type=int, default=1)
    parser.add_argument('--device', type=str, default='cuda:0')
    parser.add_argument('-i', '--index', help='string with indices separated with comma and whitespace', type=str, default = [], required=False)
    args = parser.parse_args()
    return args

if __name__ == '__main__':

    args = parse_arguments()
    num_ref_eval = args.num_ref_eval
    N = args.num_ref
    if num_ref_eval == None:
        num_ref_eval = N


    #if indexes for reference set aren't provided, create the reference set.
    if args.dataset != 'mvtec':
        if args.index != []:
            indexes = [int(item) for item in indexes.split(', ')]
        else:
            indexes = create_reference(args.contamination, args.dataset, args.normal_class, 'train', args.data_path, args.download_data, N, args.seed)


    #set the seed
    torch.manual_seed(args.weight_init_seed)
    torch.cuda.manual_seed(args.weight_init_seed)
    torch.cuda.manual_seed_all(args.weight_init_seed)


    #Initialise the model
    if args.model_type == 'CIFAR_VGG3':
        if args.pretrain == 1:
            model = CIFAR_VGG3_pre(args.vector_size, args.biases)
        else:
            model = CIFAR_VGG3(args.vector_size, args.biases)
    elif args.model_type == 'MNIST_VGG3':
        if args.pretrain == 1:
            model = MNIST_VGG3_pre(args.vector_size, args.biases)
        else:
            model = MNIST_VGG3(args.vector_size, args.biases)
    elif args.model_type == 'RESNET':
        model = RESNET_pre()
    elif args.model_type == 'RESNET50':
        model = RESNET_pre_50()
    elif args.model_type == 'RESNET_pre_101':
        model = RESNET_pre_101()
    elif (args.model_type == 'FASHION_VGG3'):
        if (args.pretrain ==1):
            model = FASHION_VGG3_pre(args.vector_size, args.biases)
        else:
            model = FASHION_VGG3(args.vector_size, args.biases)


    if (args.model_type == 'RESNET'):
        model.apply(deactivate_batchnorm)
    if (args.model_type == 'RESNET_pre_101'):
        model.apply(deactivate_batchnorm)
    #create datasets
    if args.dataset == 'mvtec':
        ref_dataset = load_dataset(args.dataset, args.index, args.normal_class, 'train', args.data_path, download_data=True, seed=args.seed, N=N)
        indexes = ref_dataset.indexes
        val_dataset = load_dataset(args.dataset, args.index, args.normal_class, 'test', args.data_path, download_data=True, seed=args.seed, N=N)
    else:
        ref_dataset = load_dataset(args.dataset, indexes, args.normal_class, 'train', args.data_path, download_data=True)
        val_dataset = load_dataset(args.dataset, indexes, args.normal_class, 'test', args.data_path, download_data=True)

    #initialise the anchor
    model.to(args.device)
    ind = list(range(0, len(indexes)))
    #select datapoint from the reference set to use as anchor
    np.random.seed(args.epochs)
    rand_freeze = np.random.randint(len(indexes) )
    base_ind = ind[rand_freeze]
    anchor = init_feat_vec(model,base_ind , ref_dataset, args.device)

    #load model
    model.load_state_dict(torch.load(args.model_path + args.model_name))

    criterion = ContrastiveLoss(args.alpha, anchor, args.device, args.v)

    val_auc, val_loss, val_auc_min, f1,acc, df, ref_vecs, inf_times, total_times = evaluate(anchor, args.seed, base_ind, ref_dataset, val_dataset, model, args.dataset, args.normal_class, args.model_name, indexes, args.data_path, criterion, args.alpha, args.num_ref_eval, args.device,epoch=0)

    #write out all details of model training
    cols = ['normal_class', 'auc_min','f1','acc']
    params = [args.normal_class, val_auc_min, f1,acc]
    string = './outputs/class_' + str(args.normal_class)
    if not os.path.exists(string):
        os.makedirs(string)
    pd.DataFrame([params], columns = cols).to_csv('./outputs/class_'+str(args.normal_class)+'/'+args.model_name)
